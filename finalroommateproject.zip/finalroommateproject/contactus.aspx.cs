﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

namespace finalroommateproject
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void sendmessage_Click(object sender, EventArgs e)
        {
            MailMessage Msg = new MailMessage();
            // Sender e-mail address.
            Msg.From = new MailAddress(emailtxt.Text.ToString());
            // Recipient e-mail address.
            Msg.To.Add("sandhukaram1313@gmail.com");
            Msg.Subject = "message" + sendertxt.Text.ToString();
            Msg.IsBodyHtml = true;
            Msg.Body = "<html><body>"
                + emailtxt.Text.ToString() +
                "<br><br>"
                + subjecttxt.Text.ToString() +
                "<br><br>"
                + messagetxt.Text.ToString() +
                "</body></html>";

            // your remote SMTP server IP.
            SmtpClient smtp = new SmtpClient("smtp.gmail.com",587);
            //    smtp.Host = "smtp.gmail.com"; 
            //smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.Credentials = new System.Net.NetworkCredential("sandhukaram1313@gmail.com", "10MAY1994");
            smtp.Send(Msg);

            //   thankslbl.Text = "Thanks for contacting us";

            Response.Write("<script>alert('Thanks for contacting us')</script>");
            emailtxt.Text = "";
            sendertxt.Text = "";
            subjecttxt.Text = "";
            messagetxt.Text="";
        }
        
    }
}