﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace finalroommateproject
{
    public partial class signup : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\register.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            for (int i = 1930; i <= 2019; i++)
            {
                yeartxt.Items.Add(i.ToString());
            }

            for (int i = 1; i <= 12; i++)
            {
                monthtxt.Items.Add(i.ToString());
            }
            for (int i = 1; i <= 31; i++)
            {
                daytxt.Items.Add(i.ToString());
            }
        }

        protected void btnregister_click(object sender, EventArgs e)
        {
            string dob = yeartxt.SelectedValue + "/" + monthtxt.SelectedValue + "/" + daytxt.SelectedValue;
            byte[] profilePicBytes = null;
            if (uploadphoto.HasFile)
            {
                //getting length of uploaded file
                int length = uploadphoto.PostedFile.ContentLength;
                //create a byte array to store the binary image data
                profilePicBytes = new byte[length];
                //store the currently selected file in memeory
                HttpPostedFile img = uploadphoto.PostedFile;
                //set the binary data
                img.InputStream.Read(profilePicBytes, 0, length);
            }
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            try
            {
                con.Open();
                cmd.CommandText = "insert  into tbregister values(@first,@last,@email,@pass,@profilepic,@age,@gen,@room)";

                cmd.Parameters.AddWithValue("@first", firsttxt.Text);
                cmd.Parameters.AddWithValue("@last", lasttxt.Text);
                cmd.Parameters.AddWithValue("@email", emailtxt.Text);
                cmd.Parameters.AddWithValue("@pass", passtxt2.Text);
                cmd.Parameters.AddWithValue("@profilepic", profilePicBytes);
                cmd.Parameters.AddWithValue("@age", dob);
                cmd.Parameters.AddWithValue("@gen", gendertxt.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@room", roommatetxt2.SelectedValue.ToString());




                // con.Open();
                cmd.ExecuteNonQuery();
                // ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Insert is successfull')", true);
                Response.Write("<script>alert('Registration Successful!Now Log In Again!..')</script>");
                cmd.Dispose();
                con.Close();
                firsttxt.Text = "";
                lasttxt.Text = "";
                emailtxt.Text = "";
                passtxt2.Text = "";
                gendertxt.SelectedItem.Text = "";
                roommatetxt2.SelectedItem.Text = "";
                yeartxt.SelectedItem.Text = "";
                monthtxt.SelectedItem.Text = "";
                daytxt.SelectedItem.Text = "";
                samelbl.Text = "";
                firsttxt.Focus();
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627)
                {
                    string msg = "Email-Id already exist! please provide another ID";

                    samelbl.Text = msg;
                    
                    samelbl.Visible = true;
                }
                // Response.Redirect("signin.aspx");
            }
        }
    }

   
    }
