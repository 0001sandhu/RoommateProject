﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

namespace finalroommateproject
{
    public partial class signin : System.Web.UI.Page
    {
        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                Response.Redirect("profile.aspx");
            }
            else

                con.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\register.mdf;Integrated Security=True";
            con.Open();
        }

        protected void signbtn1_Click(object sender, EventArgs e)
        {

            try
            {
                string user = usrtxt.Text.Trim();

                cmd.CommandText = "select * from tbregister where email='" + usrtxt.Text + "' and pass='" + pastxt1.Text + "'";

                //cmd.Parameters.Add("@id", SqlDbType.VarChar, 50).Value = usrtxt.Text;
                // cmd.Parameters.Add("@pwd", SqlDbType.VarChar, 50).Value = pastxt1.Text;
                cmd.Connection = con;
                sda.SelectCommand = cmd;
                sda.Fill(ds, "tbregister");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Session["user"] = user;
                    Response.Redirect("Profile.aspx");
                    

                }
                else
                {
                    roommatelbl1.Text = "Incorrect username or password!";
                }

                //cmd.Dispose();
               //con.Close();
                usrtxt.Text = "";
                pastxt1.Text = "";
                usrtxt.Focus();

            }
            catch (SqlException ex)
            {
                if (ex.Number == 40501)
                {
                    string msg = "Can't connect to database. Please try again!";

                    connectlbl.Text = msg;
                    connectlbl.Visible = true;

                }
            }

           

        }
    }
}