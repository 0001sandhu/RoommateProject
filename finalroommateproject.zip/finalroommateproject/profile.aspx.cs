﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;


namespace finalroommateproject
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"]== null)
            {
                Response.Redirect("signin.aspx");
            }
            else

                con.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\register.mdf;Integrated Security=True";
            con.Open();
            showdata();
        }
        public void showdata()
        {
            

            cmd.CommandText = "select * from tbregister where email='" + Session["user"] + "'";
            cmd.Connection = con;
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            Label1.Text = ds.Tables[0].Rows[0]["firstname"].ToString()+"&nbsp"+ds.Tables[0].Rows[0]["lastname"].ToString();
            Label3.Text = ds.Tables[0].Rows[0]["email"].ToString();
            Label4.Text = ds.Tables[0].Rows[0]["age"].ToString();
            Label5.Text = ds.Tables[0].Rows[0]["gender"].ToString();
            Label6.Text = ds.Tables[0].Rows[0]["room_prefer"].ToString();


            cmd.CommandText = "select profilepic from tbregister where email='" + Session["user"] + "'";
            cmd.Connection = con;
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    byte[] img = (byte[])dr["profilepic"];
                    string imagedata = Convert.ToBase64String(img, 0, img.Length);
                    Image1.ImageUrl = "data:image/png;base64," + imagedata;
                }
            }

            else
            {

            }
        }
       

    }
}