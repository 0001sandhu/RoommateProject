﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace finalroommateproject
{
    public partial class forgot : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\register.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

       
        protected void check_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select * from tbregister where email=@eid";
            cmd.Parameters.AddWithValue("@eid", emailtxt1.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {

            checkemail.Text = "User Exist";
                checkemail.Visible = true;
                dr.Read();
                
            }
            else
            {
                checkemail.Text = "Not Available";
                checkemail.Visible = true;
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
        }

        protected void get_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select * from tbregister where email=@eid";
            cmd.Parameters.AddWithValue("@eid", emailtxt2.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                //String uid = dr[0].ToString();
                String pd = dr[3].ToString();
                getpwd.Text = "Your Password : " + pd;
                getpwd.Visible = true;
   
            }
            else
            {
                getpwd.Text = "Some Errors";
                getpwd.Visible = true;
            }
            dr.Close();
            cmd.Dispose();
            con.Close();

        }
    }
}